	  <hr>

      <footer>
        <div class="foot_center2"><p>Copyright &copy; 2026 AMITY UNIVERSITY HARYANA</p>
		<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbspProgrammed by: Krish Bagaria </p>
		</div>
      </footer>