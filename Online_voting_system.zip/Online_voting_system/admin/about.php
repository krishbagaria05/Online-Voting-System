<h1><font color="gray">Online Voting System</font></h1>
</br>
<font color="#555">
<p>For Amity University</p>
<p>Develop By:</p>
</font>
</br>
<div id="accordion2" class="accordion">
<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapseOne" data-parent="#accordion2" data-toggle="collapse">Krish Bagaria</a>
</div>
<div id="collapseOne" class="accordion-body collapse" style="height: 0px;">
<div class="accordion-inner"> 
<p><font color="gray">Position:&nbsp;Programmer</font></p>
<p><font color="gray">FirstName:&nbsp;Krish</font></p>
<p><font color="gray">LastName:&nbsp;Bagaria</font></p>
<p><font color="gray">Age:&nbsp;19</font></p>
<p><font color="gray">Address:&nbsp;Haryana</font></p>
<p><font color="gray">Email:&nbsp;krishbagaria05@gmail.com</font></p>
<p><font color="gray">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;bagariakrish05@gmail.com</font></p>
<div class="user_image"><img src="project_member/kev.jpg" width="200" height="250"></div>
</div>
</div>
</div>

<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapse4" data-parent="#accordion2" data-toggle="collapse">Yogender Sharma</a>
</div>
<div id="collapse4" class="accordion-body collapse">
<div class="accordion-inner">
<p><font color="gray">Position:&nbsp;Project Manager</font></p>
<p><font color="gray">FirstName:&nbsp;Yogender</font></p>
<p><font color="gray">LastName:&nbsp;Sharma</font></p>
<p><font color="gray">Age:&nbsp;20</font></p>
<p><font color="gray">Address:&nbsp;Dharuhera</font></p>
<p><font color="gray">Email:&nbsp;yogendersharma18@gmail.com</font></p>
<div class="user_image"><img src="project_member/sherwin.jpg" width="200" height="250"></div>
</div>
</div>
</div>

<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapseTwo" data-parent="#accordion2" data-toggle="collapse">Suyash Verma</a>
</div>
<div id="collapseTwo" class="accordion-body collapse">
<div class="accordion-inner">
<p><font color="gray">Position:&nbsp;Assistant Project Manager</font></p>
<p><font color="gray">FirstName:&nbsp;Suyash</font></p>
<p><font color="gray">LastName:&nbsp;Verma</font></p>
<p><font color="gray">Age:&nbsp;19</font></p>
<p><font color="gray">Address:&nbsp;Haryana</font></p>
<p><font color="gray">Email:&nbsp;suyashverma2435@gmail.com</font></p>
<div class="user_image"><img src="project_member/may.png" width="200" height="250"></div>
</div>

</div>
</div>
<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapse3" data-parent="#accordion2" data-toggle="collapse">Ashish Jha</a>
</div>
<div id="collapse3" class="accordion-body collapse">
<div class="accordion-inner">
<p><font color="gray">Position:&nbsp;System Analyst</font></p>
<p><font color="gray">FirstName:&nbsp;Ashish</font></p>
<p><font color="gray">LastName:&nbsp;Jha</font></p>
<p><font color="gray">Age:&nbsp;21</font></p>
<p><font color="gray">Address:&nbsp;Haryana</font></p>
<p><font color="gray">Email:&nbsp;ashishjha4@yahoo.com</font></p>
<div class="user_image"><img src="project_member/golda.jpg" width="200" height="250"></div>
</div>
</div>
</div>


<div class="accordion-group">
<div class="accordion-heading">
<a class="accordion-toggle" href="#collapse5" data-parent="#accordion2" data-toggle="collapse">Jigyasa</a>
</div>
<div id="collapse5" class="accordion-body collapse">
<div class="accordion-inner">
<p><font color="gray">Position:&nbsp;Designer</font></p>
<p><font color="gray">FirstName:&nbsp;Jigyasa</font></p>
<p><font color="gray">LastName:&nbsp;</font></p>
<p><font color="gray">Age:&nbsp;19</font></p>
<p><font color="gray">Address:&nbsp;Haryana</font></p>
<p><font color="gray">Email:&nbsp;jigyasa08@yahoo.com</font></p>
<div class="user_image"><img src="project_member/ver.png" width="200" height="250"></div>
</div>
</div>
</div>
	  </div>
	  </div>