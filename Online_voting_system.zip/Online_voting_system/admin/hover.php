		<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#back').qtip({
			content: 'Click to  here  return',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>

	
	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#bak').qtip({
			content: 'Click to return',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>


	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#vote').qtip({
			content: 'Click here to Submit Vote',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>


	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#index').qtip({
			content: 'Click here to  vote later, retun to main page',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>

	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#help').qtip({
			content: 'Click here to View Help',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#excel').qtip({
			content: 'Click here to download excel File',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		

	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.UserName_hover').qtip({
			content: 'Enter your username here',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>
		
	
	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.Password_hover').qtip({
			content: 'Enter your Password here',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
 
	<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.Button_Login_Hover').qtip({
			content: 'Click Here To Login',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
		
		<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.delete_voter').qtip({
			content: 'Click Here To Delete Voter',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
		
		
		<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('.btn-danger').qtip({
			content: 'Click here to delete this Voter',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
			<script type="text/javascript" charset="utf-8">
			jQuery(document).ready(function() {
			$('#logout').qtip({
			content: 'Click Here to LogOut',
			position: {
            my: 'top left',
            target: 'mouse',
			show: { ready: true },
            viewport: $(window), // Keep it on-screen at all times if possible
            adjust: {
                x: 10,  y: 10
            }
        },
        hide: {
            fixed: true // Helps to prevent the tooltip from hiding ocassionally when tracking!
        },
        style: 'ui-tooltip-shadow'
    });					
	});		
		</script>	
		
			